#pragma once
#include <carl/numbers/numbers.h>


typedef mpq_class Rational;
typedef mpz_class Integer;