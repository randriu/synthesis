#pragma once

#include "src/common.h"

void define_boundtype(py::module& m);
