#pragma once

#include "src/common.h"

void define_interval(py::module& m);
