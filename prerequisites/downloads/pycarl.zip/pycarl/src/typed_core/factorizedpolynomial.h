#ifndef PYTHON_CORE_FACTORIZEDPOLYNOMIAL_H_
#define PYTHON_CORE_FACTORIZEDPOLYNOMIAL_H_

#include "src/common.h"

void define_factorizedpolynomial(py::module& m);

#endif /* PYTHON_CORE_FACTORIZEDPOLYNOMIAL_H_ */
