#ifndef PYTHON_CORE_FACTORIZATION_H_
#define PYTHON_CORE_FACTORIZATION_H_

#include "src/common.h"

void define_factorizationcache(py::module& m);
void define_factorization(py::module& m);

#endif /* PYTHON_CORE_FACTORIZATION_H_ */
