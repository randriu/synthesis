/*
 * polynomial.h
 *
 *  Created on: 16 Apr 2016
 *      Author: harold
 */

#ifndef PYTHON_CORE_POLYNOMIAL_H_
#define PYTHON_CORE_POLYNOMIAL_H_

#include "src/common.h"

void define_polynomial(py::module& m);

#endif /* PYTHON_CORE_POLYNOMIAL_H_ */
