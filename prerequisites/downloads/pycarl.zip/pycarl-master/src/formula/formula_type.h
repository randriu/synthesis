#pragma once

#include "src/common.h"

void define_formula_type(py::module& m);