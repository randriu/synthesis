#ifndef PYTHON_LOGIC_FORMULAE_H_
#define PYTHON_LOGIC_FORMULAE_H_

#include "src/common.h"

void define_formulae(py::module& m);

#endif /* PYTHON_LOGIC_FORMULAE_H_ */
