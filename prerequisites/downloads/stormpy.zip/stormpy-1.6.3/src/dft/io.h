#pragma once

#include "common.h"

void define_input(py::module& m);
void define_output(py::module& m);
