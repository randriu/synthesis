#pragma once

#include "common.h"

void define_analysis(py::module& m);
