#ifndef PYTHON_CORE_MODELCHECKING_H_
#define PYTHON_CORE_MODELCHECKING_H_

#include "common.h"

void define_modelchecking(py::module& m);

#endif /* PYTHON_CORE_MODELCHECKING_H_ */
