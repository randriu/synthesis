#ifndef PYTHON_CORE_BISIMULATION_H_
#define PYTHON_CORE_BISIMULATION_H_

#include "common.h"

void define_bisimulation(py::module& m);

#endif /* PYTHON_CORE_BISIMULATION_H_ */
