#pragma once

#include "common.h"

template<typename ValueType>
void define_sparse_model_simulator(py::module& m, std::string const& vtSuffix);