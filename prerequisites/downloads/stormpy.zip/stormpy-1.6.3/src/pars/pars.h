#ifndef PYTHON_PARS_PARS_H_
#define PYTHON_PARS_PARS_H_

#include "common.h"

void define_pars(py::module& m);

#endif /* PYTHON_PARS_PARS_H_ */
