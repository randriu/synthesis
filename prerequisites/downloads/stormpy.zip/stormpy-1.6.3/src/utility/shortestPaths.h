#ifndef PYTHON_UTILITY_SHORTESTPATHS_H_
#define PYTHON_UTILITY_SHORTESTPATHS_H_

#include "src/common.h"

void define_ksp(py::module& m);

#endif /* PYTHON_UTILITY_SHORTESTPATHS_H_ */
