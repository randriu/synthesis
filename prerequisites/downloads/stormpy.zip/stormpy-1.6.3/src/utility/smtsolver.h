#pragma once

#include "src/common.h"

void define_smt(py::module& m);