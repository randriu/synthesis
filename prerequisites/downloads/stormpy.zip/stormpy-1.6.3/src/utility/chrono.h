#pragma once

#include "src/common.h"

void define_chrono(py::module& m);