#ifndef PYTHON_STORAGE_LABELING_H_
#define PYTHON_STORAGE_LABELING_H_

#include "common.h"

void define_labeling(py::module& m);

#endif /* PYTHON_STORAGE_LABELING_H_ */
