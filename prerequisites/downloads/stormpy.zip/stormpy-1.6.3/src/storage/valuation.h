#pragma once

#include "common.h"

void define_statevaluation(py::module& m);
void define_simplevaluation(py::module& m);