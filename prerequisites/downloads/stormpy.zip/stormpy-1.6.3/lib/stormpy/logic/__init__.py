from . import logic
from .logic import *
