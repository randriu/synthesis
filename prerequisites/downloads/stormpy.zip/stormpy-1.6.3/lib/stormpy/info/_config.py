# Generated from setup.py at 2021-02-24 17:05:11.072706
storm_version = "1.6.3"
storm_cln_ea = False
storm_cln_rf = True