from configurations import has_pars

if has_pars:
    import stormpy.pars
