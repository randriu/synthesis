from configurations import has_dft

if has_dft:
    import stormpy.dft
