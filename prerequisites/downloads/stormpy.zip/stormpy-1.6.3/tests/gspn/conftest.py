from configurations import has_gspn

if has_gspn:
    import stormpy.gspn
