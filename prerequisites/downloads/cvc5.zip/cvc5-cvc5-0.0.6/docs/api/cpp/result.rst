Result
======

.. doxygenclass:: cvc5::api::Result
    :project: cvc5
    :members:
    :undoc-members:
