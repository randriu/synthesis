DatatypeConstructor
===================

.. doxygenclass:: cvc5::api::DatatypeConstructor
    :project: cvc5
    :members:
    :undoc-members:
