OptionInfo
==========

.. doxygenstruct:: cvc5::api::OptionInfo
    :project: cvc5
    :members:
