Datatype
========

.. doxygenclass:: cvc5::api::Datatype
    :project: cvc5
    :members:
    :undoc-members:
