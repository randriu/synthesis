Op
==

.. doxygenclass:: cvc5::api::Op
    :project: cvc5
    :members:

.. doxygenstruct:: std::hash< cvc5::api::Op >
    :project: std
    :members:
    :undoc-members:
