RoundingMode
============

.. doxygenenum:: cvc5::api::RoundingMode
    :project: cvc5

.. doxygenstruct:: std::hash< cvc5::api::RoundingMode >
    :project: std
    :members:
    :undoc-members:
