DatatypeSelector
================

.. doxygenclass:: cvc5::api::DatatypeSelector
    :project: cvc5
    :members:
    :undoc-members:
