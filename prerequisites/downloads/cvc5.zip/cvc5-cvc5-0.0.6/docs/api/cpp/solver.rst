Solver
======

.. doxygenclass:: cvc5::api::Solver
    :project: cvc5
    :members:
    :undoc-members:
