Quantifiers
============

Builders
------------------
.. autofunction:: cvc5_z3py_compat.ForAll
.. autofunction:: cvc5_z3py_compat.Exists
.. autofunction:: cvc5_z3py_compat.Lambda

Testers
-------------------
.. autofunction:: cvc5_z3py_compat.is_var
.. autofunction:: cvc5_z3py_compat.is_quantifier

Classes
-------
.. autoclass:: cvc5_z3py_compat.QuantifierRef
   :members:
   :special-members:

