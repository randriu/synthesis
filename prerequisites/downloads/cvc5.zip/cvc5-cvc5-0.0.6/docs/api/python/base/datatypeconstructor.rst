DatatypeConstructor
===================

.. autoclass:: pycvc5.DatatypeConstructor
    :members:
    :undoc-members:
