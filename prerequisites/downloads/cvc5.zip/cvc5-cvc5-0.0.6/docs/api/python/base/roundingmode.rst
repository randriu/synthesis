RoundingMode
================

.. autoclass:: pycvc5.RoundingMode
    :members:
    :undoc-members:
