DatatypeDecl
============

.. autoclass:: pycvc5.DatatypeDecl
    :members:
    :undoc-members:
