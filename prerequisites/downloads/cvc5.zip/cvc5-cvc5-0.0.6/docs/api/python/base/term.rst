Term
================

.. autoclass:: pycvc5.Term
    :members:
    :undoc-members:
