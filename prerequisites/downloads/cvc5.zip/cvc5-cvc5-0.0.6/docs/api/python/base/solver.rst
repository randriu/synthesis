Solver
========

.. autoclass:: pycvc5.Solver
    :members:
    :undoc-members:
