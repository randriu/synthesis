UnknownExplanation
==================

.. autoclass:: pycvc5.UnknownExplanation
    :members:
    :undoc-members:
