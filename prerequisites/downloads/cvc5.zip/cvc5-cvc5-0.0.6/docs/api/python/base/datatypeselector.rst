DatatypeSelector
================

.. autoclass:: pycvc5.DatatypeSelector
    :members:
    :undoc-members:
