Op
================

.. autoclass:: pycvc5.Op
    :members:
    :undoc-members:
