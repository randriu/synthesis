Result
================

.. autoclass:: pycvc5.Result
    :members:
    :undoc-members:
