Exception Handling
======================================


.. api-examples::
    <examples>/api/java/Exceptions.java
    <examples>/api/python/exceptions.py
