Theory of Bit-Vectors
=====================


.. api-examples::
    <examples>/api/cpp/bitvectors.cpp
    <examples>/api/java/BitVectors.java
    <z3pycompat>/test/pgms/example_bitvectors.py
    <examples>/api/python/bitvectors.py
    <examples>/api/smtlib/bitvectors.smt2
