Theory of Bit-Vectors and Arrays
================================


.. api-examples::
    <examples>/api/cpp/bitvectors_and_arrays.cpp
    <examples>/api/java/BitVectorsAndArrays.java
    <z3pycompat>/test/pgms/example_bitvectors_and_arrays.py
    <examples>/api/python/bitvectors_and_arrays.py
    <examples>/api/smtlib/bitvectors_and_arrays.smt2
