SyGuS: Functions
===================


.. api-examples::
    <examples>/api/cpp/sygus-fun.cpp
    <examples>/api/java/SygusFun.java
    <examples>/api/python/sygus-fun.py
    <examples>/api/smtlib/sygus-fun.sy
