Theory Combination
==================

.. api-examples::
    <examples>/api/cpp/combination.cpp
    <examples>/api/java/Combination.java
    <z3pycompat>/test/pgms/example_combination.py
    <examples>/api/python/combination.py
    <examples>/api/smtlib/combination.smt2
