Theory of Sets
=================


.. api-examples::
    <examples>/api/cpp/sets.cpp
    <examples>/api/java/Sets.java
    <z3pycompat>/test/pgms/example_sets.py
    <examples>/api/python/sets.py
    <examples>/api/smtlib/sets.smt2
