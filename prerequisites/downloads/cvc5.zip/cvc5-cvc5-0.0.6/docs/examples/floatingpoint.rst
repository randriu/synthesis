Theory of Floating-Points
======================================


.. api-examples::
    <examples>/api/cpp/floating_point_arith.cpp
    <examples>/api/java/FloatingPointArith.java
    <z3pycompat>/test/pgms/example_floating_point.py
    <examples>/api/python/floating_point.py
