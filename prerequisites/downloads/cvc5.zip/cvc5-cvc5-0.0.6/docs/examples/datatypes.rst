Theory of Datatypes
===================


.. api-examples::
    <examples>/api/cpp/datatypes.cpp
    <examples>/api/java/Datatypes.java
    <z3pycompat>/test/pgms/example_datatypes.py
    <examples>/api/python/datatypes.py
    <examples>/api/smtlib/datatypes.smt2
