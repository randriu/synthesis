Input Languages
===============

cvc5 supports the following input languages:

* `SMT-LIB v2 <http://smtlib.cs.uiowa.edu/language.shtml>`_
* `SyGuS-IF <https://sygus.org/language/>`_
* `TPTP <http://www.tptp.org/>`_
