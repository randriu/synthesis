Output tags
===========

cvc5 supports printing information about certain aspects of the solving process
that is intended for regular users. These can be enabled using the
:ref:`-o <lbl-option-output>` command line flag.

As of now, the following output tags are supported:

.. include-build-file:: output_tags_generated.rst
