/******************************************************************************
 * Top contributors (to current version):
 *   Kshitij Bansal, Andrew Reynolds, Morgan Deters
 *
 * This file is part of the cvc5 project.
 *
 * Copyright (c) 2009-2021 by the authors listed in the file AUTHORS
 * in the top-level source directory and their institutional affiliations.
 * All rights reserved.  See the file COPYING in the top-level source
 * directory for licensing information.
 * ****************************************************************************
 *
 * Old implementation of the decision engine
 */

#include "cvc5_private.h"

#ifndef CVC5__DECISION__DECISION_ENGINE_OLD_H
#define CVC5__DECISION__DECISION_ENGINE_OLD_H

#include "base/output.h"
#include "context/cdo.h"
#include "decision/decision_engine.h"
#include "decision/decision_strategy.h"
#include "expr/node.h"
#include "prop/cnf_stream.h"
#include "prop/sat_solver.h"
#include "prop/sat_solver_types.h"
#include "util/result.h"

using namespace cvc5::prop;
using namespace cvc5::decision;

namespace cvc5 {

class DecisionEngineOld : public decision::DecisionEngine
{
 public:
  // Necessary functions

  /** Constructor */
  DecisionEngineOld(Env& env);

  /** Destructor, currently does nothing */
  ~DecisionEngineOld()
  {
    Trace("decision") << "Destroying decision engine" << std::endl;
  }

  /**
   * This is called by SolverEngine, at shutdown time, just before
   * destruction.  It is important because there are destruction
   * ordering issues between some parts of the system.
   */
  void shutdown();

  // Interface for External World to use our services

  /** Gets the next decision based on strategies that are enabled */
  SatLiteral getNextInternal(bool& stopSearch) override;

  /** Is the DecisionEngineOld in a state where it has solved everything? */
  bool isDone() override
  {
    Trace("decision") << "DecisionEngineOld::isDone() returning "
                      << (d_result != SAT_VALUE_UNKNOWN)
                      << (d_result != SAT_VALUE_UNKNOWN ? "true" : "false")
                      << std::endl;
    return (d_result != SAT_VALUE_UNKNOWN);
  }

  /** */
  Result getResult()
  {
    switch (d_result.get())
    {
      case SAT_VALUE_TRUE: return Result(Result::SAT);
      case SAT_VALUE_FALSE: return Result(Result::UNSAT);
      case SAT_VALUE_UNKNOWN:
        return Result(Result::SAT_UNKNOWN, Result::UNKNOWN_REASON);
      default: Assert(false) << "d_result is garbage";
    }
    return Result();
  }

  /** */
  void setResult(SatValue val) { d_result = val; }

  // External World helping us help the Strategies

  /**
   * Notify this class that assertion is an (input) assertion, not corresponding
   * to a skolem definition.
   */
  void addAssertion(TNode assertion, bool isLemma) override;
  /**
   * Notify this class  that lem is the skolem definition for skolem, which is
   * a part of the current assertions.
   */
  void addSkolemDefinition(TNode lem, TNode skolem, bool isLemma) override;

  // Interface for Strategies to use stuff stored in Decision Engine
  // (which was possibly requested by them on initialization)

  // Interface for Strategies to get information about External World

  bool hasSatLiteral(TNode n) { return d_cnfStream->hasLiteral(n); }
  SatLiteral getSatLiteral(TNode n) { return d_cnfStream->getLiteral(n); }
  SatValue getSatValue(SatLiteral l) { return d_satSolver->value(l); }
  SatValue getSatValue(TNode n) { return getSatValue(getSatLiteral(n)); }
  Node getNode(SatLiteral l) { return d_cnfStream->getNode(l); }

 private:
  // Disable creating decision engine without required parameters
  DecisionEngineOld();

  // Does decision engine know the answer?
  context::CDO<SatValue> d_result;

  // init/shutdown state
  unsigned d_engineState;  // 0=pre-init; 1=init,pre-shutdown; 2=shutdown
  /** The ITE decision strategy we have allocated */
  std::unique_ptr<ITEDecisionStrategy> d_enabledITEStrategy;
  /** Whether we are using stop only */
  bool d_decisionStopOnly;

}; /* DecisionEngineOld class */

}  // namespace cvc5

#endif /* CVC5__DECISION__DECISION_ENGINE_H */
