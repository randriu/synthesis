Theory References
=================

cvc5 implements several theories that are not (yet) standardized in SMT-LIB, or
that extend beyond the respective standardized theory.

.. toctree::
   :maxdepth: 1

   datatypes
   separation-logic
   sets-and-relations
   transcendentals
