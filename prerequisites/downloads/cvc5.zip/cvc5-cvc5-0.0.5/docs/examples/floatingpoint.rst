Theory of Floating-Points
======================================


.. api-examples::
    <examples>/api/java/FloatingPointArith.java
    <examples>/api/python/floating_point.py
