Quickstart Example
==================


.. api-examples::
    <examples>/api/cpp/quickstart.cpp
    <examples>/api/java/QuickStart.java
    <examples>/api/python/quickstart.py
    <examples>/api/smtlib/quickstart.smt2
