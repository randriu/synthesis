Theory of Bit-Vectors
=====================


.. api-examples::
    <examples>/api/cpp/bitvectors.cpp
    <examples>/api/java/BitVectors.java
    <examples>/api/python/bitvectors.py
    <examples>/api/smtlib/bitvectors.smt2
