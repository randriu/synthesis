Theory Combination
==================

.. api-examples::
    <examples>/api/cpp/combination.cpp
    <examples>/api/java/Combination.java
    <examples>/api/python/combination.py
    <examples>/api/smtlib/combination.smt2
