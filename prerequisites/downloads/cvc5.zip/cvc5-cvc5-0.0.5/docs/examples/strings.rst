Theory of Strings
=================


.. api-examples::
    <examples>/api/cpp/strings.cpp
    <examples>/api/java/Strings.java
    <examples>/api/python/strings.py
    <examples>/api/smtlib/strings.smt2
