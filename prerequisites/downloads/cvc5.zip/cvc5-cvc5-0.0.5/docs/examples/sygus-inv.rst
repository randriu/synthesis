SyGuS: Invariants
===================


.. api-examples::
    <examples>/api/cpp/sygus-inv.cpp
    <examples>/api/java/SygusInv.java
    <examples>/api/python/sygus-inv.py
    <examples>/api/smtlib/sygus-inv.sy
