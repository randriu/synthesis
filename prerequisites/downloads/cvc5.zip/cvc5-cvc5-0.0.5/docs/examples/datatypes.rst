Theory of Datatypes
===================


.. api-examples::
    <examples>/api/cpp/datatypes.cpp
    <examples>/api/java/Datatypes.java
    <examples>/api/python/datatypes.py
    <examples>/api/smtlib/datatypes.smt2
