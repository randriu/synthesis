SyGuS: Grammars
===================


.. api-examples::
    <examples>/api/cpp/sygus-grammar.cpp
    <examples>/api/java/SygusGrammar.java
    <examples>/api/python/sygus-grammar.py
    <examples>/api/smtlib/sygus-grammar.sy
