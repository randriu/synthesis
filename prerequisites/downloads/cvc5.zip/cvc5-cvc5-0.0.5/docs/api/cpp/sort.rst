Sort
====

.. doxygenclass:: cvc5::api::Sort
    :project: cvc5
    :members:
    :undoc-members:

.. doxygenstruct:: std::hash< cvc5::api::Sort >
    :project: std
    :members:
    :undoc-members:
