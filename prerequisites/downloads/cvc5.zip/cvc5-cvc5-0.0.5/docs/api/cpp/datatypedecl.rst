DatatypeDecl
============

.. doxygenclass:: cvc5::api::DatatypeDecl
    :project: cvc5
    :members:
    :undoc-members:
