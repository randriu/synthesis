DatatypeConstructorDecl
=======================

.. doxygenclass:: cvc5::api::DatatypeConstructorDecl
    :project: cvc5
    :members:
    :undoc-members:
