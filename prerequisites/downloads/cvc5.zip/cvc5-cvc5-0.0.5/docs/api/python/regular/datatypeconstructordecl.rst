DatatypeConstructorDecl
=======================

.. autoclass:: pycvc5.DatatypeConstructorDecl
    :members:
    :undoc-members:
