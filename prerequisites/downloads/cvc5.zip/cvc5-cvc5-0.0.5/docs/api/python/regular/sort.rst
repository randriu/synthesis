Sort
================

.. autoclass:: pycvc5.Sort
    :members:
    :undoc-members:
