Datatype
========

.. autoclass:: pycvc5.Datatype
    :members:
    :undoc-members:
