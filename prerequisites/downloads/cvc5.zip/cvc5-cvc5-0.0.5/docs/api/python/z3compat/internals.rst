Internals
============


Testers
-------------------
.. autofunction:: cvc5_z3py_compat.is_expr
.. autofunction:: cvc5_z3py_compat.is_sort
.. autofunction:: cvc5_z3py_compat.is_app
.. autofunction:: cvc5_z3py_compat.is_app_of

Exceptions
-------------------

.. autoclass:: cvc5_z3py_compat.SMTException
   :members:
   :special-members:
