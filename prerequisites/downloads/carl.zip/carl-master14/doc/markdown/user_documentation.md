User Documentation {#userdoc}
============================

This is the introductory user documentation of CArL.
It explains the basic concepts and classes that CArL provides.

Basic concepts
---------------------
- @subpage numbers
- @subpage polynomials
- @subpage formulas


Tutorial
---------------------

There are some introductory code examples how CArL can be used.
You find them at @subpage tutorial .
