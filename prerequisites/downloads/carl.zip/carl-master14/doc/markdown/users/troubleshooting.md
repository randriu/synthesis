Troubleshooting {#troubleshooting}
=================================

General 
-----------------------

CArL tries to make use of modern C++ features.
Though we try to be compatible with the stock versions of all dependencies of Debian stable and the latest Ubuntu LTS, this does not always work out.
