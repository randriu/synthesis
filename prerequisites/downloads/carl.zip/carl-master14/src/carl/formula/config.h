/**
 * Auto generated file config.h from config.h.in.
 */ 
#pragma once

/* #undef LOGGING_DISABLE_INEFFICIENT */
/* #undef VARIABLE_PASS_BY_VALUE */
