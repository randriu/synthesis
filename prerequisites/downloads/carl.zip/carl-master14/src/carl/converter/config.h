/**
 * Auto generated file config.h from config.h.in.
 */ 
#pragma once

#define USE_GINAC
/* #undef COMPARE_WITH_Z3 */
