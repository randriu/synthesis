/** 
 * @file:   PolynomialAllocator.h
 * @author: Sebastian Junges
 *
 * @since September 25, 2013
 */

#pragma once

namespace carl
{
struct NoAllocator
{
	
};
}