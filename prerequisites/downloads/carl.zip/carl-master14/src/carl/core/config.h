/**
 * Auto generated file config.h from config.h.in.
 */ 
#pragma once
#include "../config.h"
/* #undef VARIABLE_PASS_BY_VALUE */
#define PRUNE_MONOMIAL_POOL
