/**
 * Auto generated file config.h from config.h.in.
 */ 
#pragma once

#define CARL_BUILD_RELEASE
/* #undef LOGGING */
/* #undef LOGGING_DISABLE_INEFFICIENT */
#define THREAD_SAFE
/* #undef USE_BLISS */
/* #undef USE_COCOA */
