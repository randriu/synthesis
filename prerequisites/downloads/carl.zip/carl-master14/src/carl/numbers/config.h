/**
 * Auto generated file config.h from config.h.in.
 */

#include "../config.h"

#ifndef INCLUDED_FROM_NUMBERS_H
static_assert(false, "This file may only be included indirectly by numbers.h");
#endif

/* #undef USE_MPFR_FLOAT */
#define USE_CLN_NUMBERS
/* #undef USE_Z3_NUMBERS */
