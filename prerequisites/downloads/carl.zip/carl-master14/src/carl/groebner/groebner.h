/** 
 * @file:   groebner.h
 * @author: Sebastian Junges
 *
 * @since August 27, 2013
 */

#pragma once

#include "GBProcedure.h"
#include "gb-buchberger/Buchberger.h"
#include "Reductor.h"