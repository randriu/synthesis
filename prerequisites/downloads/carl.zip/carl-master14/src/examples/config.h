/**
 * Auto generated file config.h from config.h.in.
 */

/* #undef USE_MPFR_FLOAT */
