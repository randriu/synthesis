#pragma once

#include "config.h"

#ifdef USE_GINAC
#include <ginac/ginac.h>
#undef deprecated
#endif
